fdcount [![Travis CI Status](https://travis-ci.org/getlantern/fdcount.svg?branch=master)](https://travis-ci.org/getlantern/fdcount)&nbsp;[![Coverage Status](https://coveralls.io/repos/getlantern/fdcount/badge.png)](https://coveralls.io/r/getlantern/fdcount)&nbsp;[![GoDoc](https://godoc.org/github.com/getlantern/fdcount?status.png)](http://godoc.org/github.com/getlantern/fdcount)
==========
package fdcount contains provides utility functions for counting file
descriptors used by the current process.