connpool [![Travis CI Status](https://travis-ci.org/getlantern/connpool.svg?branch=master)](https://travis-ci.org/getlantern/connpool)&nbsp;[![Coverage Status](https://coveralls.io/repos/getlantern/connpool/badge.png)](https://coveralls.io/r/getlantern/connpool)&nbsp;[![GoDoc](https://godoc.org/github.com/getlantern/connpool?status.png)](http://godoc.org/github.com/getlantern/connpool)
==========
net.Conn pooling for Go.

[GoDoc](https://godoc.org/github.com/getlantern/connpool)

