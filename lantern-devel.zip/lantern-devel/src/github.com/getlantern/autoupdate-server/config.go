package main

import (
	"time"
)

const (
	githubRefreshTime     = time.Minute * 30
	localPatchesDirectory = "./patches/"
)
