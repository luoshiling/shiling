// +build !windows

package edgedetect

func defaultBrowserIsEdge() bool {
	return false
}
