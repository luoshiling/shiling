See [GoDoc](http://godoc.org/github.com/getlantern/detour)
