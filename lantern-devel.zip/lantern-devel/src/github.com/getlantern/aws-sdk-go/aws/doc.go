// Package aws contains support code for the various AWS clients in the
// github.com/awslabs/aws-sdk-go/gen subpackages.
package aws
