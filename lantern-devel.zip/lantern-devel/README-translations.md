#Translations

All Lantern translations are done in the [Lantern project in Transifex](https://www.transifex.com/otf/lantern/):


##Updating translations

To update translations from Transifex, you need the [Transifex command line tool `tx`](http://docs.transifex.com/client/setup/).

In a project that already has its associate Transifex setup configured, such as lantern-ui and lantern-mobile you can simply run:

```
tx pull -a
```
